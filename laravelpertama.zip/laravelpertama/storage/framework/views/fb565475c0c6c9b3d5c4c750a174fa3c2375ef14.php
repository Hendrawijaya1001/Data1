<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>urutan</title>
</head>
<body>
    Urutan ke - <?php echo e($ke); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\laravelpertama\resources\views/urutan.blade.php ENDPATH**/ ?>