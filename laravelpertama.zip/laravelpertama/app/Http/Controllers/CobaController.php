<?php

namespace App\http\Controllers;

use Illuminate\http\Request;

class CobaController extends Controller
{
    public function index()
    {
        return 'test berhasil';
    }

public function urutan($ke)
{
    return view ('urutan', ['ke' => $ke]);
}  
}